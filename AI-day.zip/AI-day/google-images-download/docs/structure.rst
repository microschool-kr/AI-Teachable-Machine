========
Workflow
========

Link to `GitHub repo <https://github.com/hardikvasa/google-images-download>`__

Link to `Documentation Homepage <https://google-images-download.readthedocs.io/en/latest/index.html>`__

Below diagram represents the algorithm logic to download images.

.. figure:: http://www.zseries.in/flow-chart.png
   :alt: